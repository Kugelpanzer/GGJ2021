﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericPlanet : Planet
{

    public virtual void GenerateLook()
    {

    }
    // Start is called before the first frame update
    void Start()
    {
        GenerateName();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
