﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cor
{
    public int x;
    public int y;

    public Cor(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
}
